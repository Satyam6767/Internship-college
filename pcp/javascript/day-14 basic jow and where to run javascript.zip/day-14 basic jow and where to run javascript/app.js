// let a = 123421354;
// let b = 8753284;
// let c = "abcd ";




// console.log(a+b)
// console.log(a-b)
// console.log(a*b)

// console.log(c)
// console.log(typeof c)


let answer = false;
console.log(answer);

console.log(typeof(answer))
