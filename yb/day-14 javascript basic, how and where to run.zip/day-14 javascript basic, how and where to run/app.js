const  a = "123432";
const  b = 8767656;


console.log(a+b)
console.log(a*b)


console.log(typeof a)
console.log(typeof(a))